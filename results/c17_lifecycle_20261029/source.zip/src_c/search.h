#ifndef PCAP_SEARCH_H
#define PCAP_SEARCH_H
#include "common.h"
typedef struct StreamIndex StreamIndex;
typedef struct StreamOptions {
    size_t tile_points, budget_bytes, window_queries;
    unsigned group, slots;
    int overlap, resident;
} StreamOptions;
typedef struct StreamStats {
    double build_ms, search_ms, sort_ms, h2d_bytes, calibration_ms, predicted_ms;
    size_t tiles, loads, executor_bytes, host_bytes, windows, selected_tile_points;
} StreamStats;
double clock_ms(void);
int stream_build(const PointSet *, float, const StreamOptions *, StreamIndex **, StreamStats *,
                 char *, size_t);
int stream_query(StreamIndex *, const PointSet *, unsigned, SearchResult *, StreamStats *, char *,
                 size_t);
void stream_free(StreamIndex *);
#endif
